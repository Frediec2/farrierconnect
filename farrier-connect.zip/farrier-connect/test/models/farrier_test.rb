require 'test_helper'

class FarrierTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
