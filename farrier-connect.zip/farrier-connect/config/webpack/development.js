process.env.NODE_ENV = process.env.NODE_ENV || 'development'

const environment = require('./environment')

const lessLoader = {
        test: /\.less$/,
        use: [ { loader: 'style-loader' }, { loader: 'css-loader' },{loader: 'less-loader' }]
      }

environment.loaders.append('less', lessLoader)

module.exports = environment.toWebpackConfig()