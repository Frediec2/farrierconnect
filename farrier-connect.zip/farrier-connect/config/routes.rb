Rails.application.routes.draw do
  
  devise_for :users, controllers: {
    sessions: 'users/sessions',
    registrations: 'users/registrations',
    passwords: 'users/passwords',
    confirmations: 'users/confirmations',
    unlocks: 'users/unlocks'
  }
  
  devise_for :farriers, controllers: {
    sessions: 'farriers/sessions',
    registrations: 'farriers/registrations',
    passwords: 'farriers/passwords',
    confirmations: 'farriers/confirmations',
    unlocks: 'farriers/unlocks'
  }
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  
  root 'static#home'
  
  get 'dashboard', to: "static#dashboard"
  get 'farrier_dashboard', to: "static#farrier_dashboard"
end
