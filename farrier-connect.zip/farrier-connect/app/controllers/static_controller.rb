class StaticController < ApplicationController
  
  def home
  end
  
  
  def dashboard
  end
  
  def farrier_dashboard
  end
  
end