import React, { Component } from 'react';
import { Form, Button, Row, Col, Image } from 'react-bootstrap';
import 'holderjs';

class UserDetails extends Component{

    saveAndContinue = (e) => {
        e.preventDefault()
        var name = this.refs.name.value;
        this.props.nextStep()
    }
    
    state = {
      phones: [{added: true}]
    };
    
    addClick(i){
      this.setState(prevState => ({ 
      	phones: [...prevState.phones, {added: true}]
      }))
    }
    
    testClick(i){
      let items = [...this.state.phones];
      let item = {...items[i]}
      item.added = false
      items[i] = item
      this.setState(prevState => ({ 
      	phones: [...items, {added: true}]
      }))
    }
    
    removeClick(i){
      let phones = [...this.state.phones];
      phones.splice(i, 1);
      this.setState({ phones });
    }
    

    render(){
        const { values } = this.props;
        
        const btnStyle = {
          marginTop: '31px'
        };
        return(
            <Form>
              <h1>Fill in your registration details.</h1>
              <Row>
                <Col xs={6} md={4}>
                  <Image src="holder.js/171x180" rounded />
                </Col>
              </Row>
              <Row>
                <Col xs={6} md={4}>
                  <Form.Group controlId="exampleForm.ControlInput1">
                    <Form.File id="formcheck-api-regular">
                      <Form.File.Input />
                    </Form.File>
                  </Form.Group>
                </Col>
              </Row>
              <Form.Group controlId="exampleForm.ControlInput1">
                <Row>
                    <Col>
                      <Form.Label>Title</Form.Label>
                      <Form.Control as="select">
                        <option>Mr.</option>
                        <option>Mrs.</option>
                        <option>Ms.</option>
                        <option>Miss.</option>
                      </Form.Control>
                    </Col>
                    <Col>
                      <Form.Label>First Name</Form.Label>
                      <Form.Control placeholder="First name" />
                    </Col>
                    <Col>
                      <Form.Label>Middle Name</Form.Label>
                      <Form.Control placeholder="Middle name" />
                    </Col>
                    <Col>
                      <Form.Label>Last Name</Form.Label>
                      <Form.Control placeholder="Last name" />
                    </Col>
                    <Col>
                      <Form.Label>Suffix</Form.Label>
                      <Form.Control as="select">
                        <option>Jr.</option>
                        <option>Sr.</option>
                        <option>II</option>
                        <option>III</option>
                        <option>IX</option>
                      </Form.Control>
                    </Col>
                  </Row>
              </Form.Group>
              <Form.Group controlId="exampleForm.ControlSelect1">
                <Row>
                    <Col>
                      <Form.Label>Email</Form.Label>
                      <Form.Control placeholder="Email" />
                    </Col>
                </Row>
                
              </Form.Group>
          {
                React.Children.toArray(
                  this.state.phones.map((item, i) => {
                    let button;
                    if (item.added) {
                      button = <input type='button' className="btn btn-primary" value='+' style={btnStyle} onClick={this.testClick.bind(this, i)} />
                    } else {
                      button = <input type='button' className="btn btn-primary" value='-' style={btnStyle} onClick={this.removeClick.bind(this, i)} />
                    }
                    return <Form.Group controlId="exampleForm.ControlSelect1" key={i}>
                              <Row>
                                <Col>
                                  <Form.Label>Phone</Form.Label>
                                  <Form.Control as="select">
                                    <option>Cell</option>
                                    <option>Work</option>
                                    <option>Home</option>
                                  </Form.Control>
                                </Col>
                                <Col>
                                  <Form.Label>Contact #</Form.Label>
                                  <Form.Control type="text" name="address" id="exampleAddress" placeholder="(xxx) xxx-xxxx"/>
                                </Col>
                                <Col md={2}>
                                  {button}
                                </Col>
                              </Row>
                            </Form.Group>
                  })
                )
              }
              <Form.Group>
                <Form.Label>Address</Form.Label>
                <Form.Control type="text" name="address" id="exampleAddress" placeholder="1234 Main St"/>
              </Form.Group>
              
              <Form.Group>
                <Form.Label>Address 2</Form.Label>
                <Form.Control type="text" name="address2" id="exampleAddress2" placeholder="Apartment, studio, or floor"/>
              </Form.Group>
              <Row>
                <Col md={6}>
                  <Form.Group>
                    <Form.Label>City</Form.Label>
                    <Form.Control type="text" name="city" id="exampleCity"/>
                  </Form.Group>
                </Col>
                <Col md={4}>
                  <Form.Group>
                    <Form.Label>State</Form.Label>
                    <Form.Control type="text" name="state" id="exampleState"/>
                  </Form.Group>
                </Col>
                <Col md={2}>
                  <Form.Group>
                    <Form.Label>Zip</Form.Label>
                    <Form.Control type="text" name="zip" id="exampleZip" ref="name"/>
                  </Form.Group>  
                </Col>
              </Row>
              <Button onClick={this.saveAndContinue}>Save And Continue </Button>
            </Form>
        )
    }
}

export default UserDetails;