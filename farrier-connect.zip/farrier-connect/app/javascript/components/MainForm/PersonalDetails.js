import React, { Component } from 'react';
import { Form, Button, Col, Row } from 'react-bootstrap';
import { throws } from 'assert';
import Select from 'react-select';
import CreatableSelect from 'react-select/creatable';
import CurrencyInput from 'react-currency-input-field';
import { DateTime } from 'react-datetime-bootstrap';
import Uppy from '@uppy/core';
import Tus from '@uppy/tus';
import { DragDrop } from '@uppy/react';
import Moment from 'moment'
import momentLocalizer from 'react-widgets-moment';
import DateTimePicker from 'react-widgets/lib/DateTimePicker';
import moment from 'moment';

import 'bootstrap/dist/css/bootstrap.css'
import 'react-widgets/dist/css/react-widgets.css'
import 'react-datetime-bootstrap/dist/style.css'
import '@uppy/core/dist/style.css'
import '@uppy/drag-drop/dist/style.css'



class PersonalDetails extends Component{
  
  
    
    saveAndContinue = (e) => {
        e.preventDefault();
        this.props.nextStep();
    }

    back  = (e) => {
        e.preventDefault();
        this.props.prevStep();
    }
    
    state = {
      pricings: [{selectedOption: null, inputValue: null, selectedAccessory: null }]
      };
      
      addClick(){
        this.setState(prevState => ({ 
        	pricings: [...prevState.pricings, {selectedOption: null, inputValue: null, selectedAccessory: null }]
        }))
      }
          
      
      
      createUpload() {
        const uppy = Uppy({
          meta: { type: 'avatar' },
          restrictions: { maxNumberOfFiles: 1 },
          autoProceed: true
        })

        uppy.use(Tus, { endpoint: '/upload' })

        uppy.on('complete', (result) => {
          
          console.log("Success");
          //const url = result.successful[0].uploadURL
          //store.dispatch({
            //type: 'SET_USER_AVATAR_URL',
            //payload: { url: url }
          //})
        })
        
        const currentAvatar = null;
        
        return (
          <div>
            <DragDrop
              uppy={uppy}
              locale={{
                strings: {
                  // Text to show on the droppable area.
                  // `%{browse}` is replaced with a link that opens the system file selection dialog.
                  dropHereOr: 'Drop here or %{browse}',
                  // Used as the label for the link that opens the system file selection dialog.
                  browse: 'browse'
                }
              }}
            />
          </div>
        )
      }
    
    createAccessories(){
      const accessory_options = [          
        { value: 'Steel', label: 'Steel' },
        { value: 'Aluminum', label: 'Aluminum' },
        { value: 'Pads', label: 'Pads' },
        { value: 'Egg Bar', label: 'Egg Bar' },
        { value: 'Straight Bar', label: 'Straight Bar' },
        { value: 'Sedatives', label: 'Sedatives' },
        { value: 'Specialty shoes', label: 'Specialty shoes' },
        { value: 'Rimmed shoes', label: 'Rimmed shoes' },
        { value: 'Leather pads', label: 'Leather pads' },
        { value: 'Plastic pads', label: 'Plastic pads' },
        { value: 'Equipack', label: 'Equipack' },
      ];
      
    }

      
    
    createUI(){
      const options = [          
        { value: 'Half Trim', label: 'Half Trim' },
        { value: 'Half Trim (front)', label: 'Half Trim (front)' },
        { value: 'Half Trim (back)', label: 'Half Trim (back)' },
        { value: 'Full Trim', label: 'Full Trim' },
        { value: 'Half Shoe', label: 'Half Shoe' },
        { value: 'Half Shoe (front)', label: 'Half Shoe (front)' },
        { value: 'Half Shoe (back)', label: 'Half Shoe (back)' },
        { value: 'Full Shoe', label: 'Full Shoe' },
        { value: 'Hot Shoe', label: 'Hot Shoe' },
        { value: 'Cold Shoe', label: 'Cold Shoe' },
        { value: 'Half Corrective Shoe', label: 'Half Corrective Shoe' },
        { value: 'Half Corrective Shoe (front)', label: 'Half Corrective Shoe (front)' },
        { value: 'Half Corrective Shoe (back)', label: 'Half Corrective Shoe (back)' },
        { value: 'Full Corrective Shoe', label: 'Full Corrective Shoe' }
      ];
      
      
      const accessory_options = [          
        { value: 'Steel', label: 'Steel' },
        { value: 'Aluminum', label: 'Aluminum' },
        { value: 'Pads', label: 'Pads' },
        { value: 'Egg Bar', label: 'Egg Bar' },
        { value: 'Straight Bar', label: 'Straight Bar' },
        { value: 'Specialty shoes', label: 'Specialty shoes' },
        { value: 'Rimmed shoes', label: 'Rimmed shoes' },
        { value: 'Leather pads', label: 'Leather pads' },
        { value: 'Plastic pads', label: 'Plastic pads' },
        { value: 'Equipack', label: 'Equipack' },
      ];
      
      const sedative = [          
        { value: 'Acepromazine (Ace)', label: 'Acepromazine (Ace)' },
        { value: 'Dormosedan', label: 'Dormosedan' },
        { value: 'Phenylbutazone (Bute)', label: 'Phenylbutazone (Bute)' }
      ];
      
      return this.state.pricings.map((el, i) => (
        <Row key={i} className="mt-3">
            <Col md={8}>
              <Form.Label>Sedatives</Form.Label>
              <CreatableSelect
                      isClearable
                      value={el.selectedAccessory}
                      onChange={this.handleSelectedAChange.bind(this, i)}
                      options={sedative}
                    />
            </Col>
            
            <Col md={2}>
              <Form.Label>Pricing</Form.Label>
              <CurrencyInput
                id="input-example"
                name="input-name"
                className="form-control"
                placeholder="$0.00"
                prefix="$"
                allowDecimals={true}
                decimalsLimit={2}
              />
            </Col>
            <Col md={2}>
              <input type='button' className="btn btn-primary mt-4" value='-' onClick={this.removeClick.bind(this, i)}/>
            </Col>
          </Row>
              ))
    }
    
    removeClick(i){
        let pricings = [...this.state.pricings];
        pricings.splice(i, 1);
        this.setState({ pricings });
     }
      
    handleSelectedChange(i, e){
        const value = e.value;
        let pricings = [...this.state.pricings];
        pricings[i] = {...pricings[i], selectedOption: e}
        this.setState({pricings}, () => console.log('Option selected:', this.state.pricings[i]));
      };
      
    handleSelectedAChange(i, e){
        const value = e.value;
        let pricings = [...this.state.pricings];
        pricings[i] = {...pricings[i], selectedAccessory: e}
        this.setState({pricings}, () => console.log('Option selected:', this.state.pricings[i].selectedOption));
    };
      
    handleInputChange = inputValue => {
        console.log("Input changed")
    };
    
    

    

    render(){
               
        Moment.locale('en')
        momentLocalizer()
      
        const options = [          
          { value: 'Half Trim', label: 'Half Trim' },
          { value: 'Half Trim (front)', label: 'Half Trim (front)' },
          { value: 'Half Trim (back)', label: 'Half Trim (back)' },
          { value: 'Full Trim', label: 'Full Trim' },
          { value: 'Half Shoe', label: 'Half Shoe' },
          { value: 'Half Shoe (front)', label: 'Half Shoe (front)' },
          { value: 'Half Shoe (back)', label: 'Half Shoe (back)' },
          { value: 'Full Shoe', label: 'Full Shoe' },
          { value: 'Hot Shoe', label: 'Hot Shoe' },
          { value: 'Cold Shoe', label: 'Cold Shoe' },
          { value: 'Half Corrective Shoe', label: 'Half Corrective Shoe' },
          { value: 'Half Corrective Shoe (front)', label: 'Half Corrective Shoe (front)' },
          { value: 'Half Corrective Shoe (back)', label: 'Half Corrective Shoe (back)' },
          { value: 'Full Corrective Shoe', label: 'Full Corrective Shoe' }
        ];
        
        
        const accessory_options = [          
          { value: 'Steel', label: 'Steel' },
          { value: 'Aluminum', label: 'Aluminum' },
          { value: 'Pads', label: 'Pads' },
          { value: 'Egg Bar', label: 'Egg Bar' },
          { value: 'Straight Bar', label: 'Straight Bar' },
          { value: 'Specialty shoes', label: 'Specialty shoes' },
          { value: 'Rimmed shoes', label: 'Rimmed shoes' },
          { value: 'Leather pads', label: 'Leather pads' },
          { value: 'Plastic pads', label: 'Plastic pads' },
          { value: 'Equipack', label: 'Equipack' },
        ];
        
        return(
              
              <Form>
              <Form.Group controlId="exampleForm.ControlInput1">
                <Row className="mt-3">
                    <Col md={8}>
                      <Form.Label>Category of Services</Form.Label>
                      <CreatableSelect
                              isClearable
                              value={null}
                              onChange={this.handleSelectedChange.bind(this)}
                              onInputChange={this.handleInputChange}
                              options={options}
                              simpleValue={true}
                            />
                    </Col>
    
                    <Col md={2}>
                      <Form.Label>Pricing</Form.Label>
                      <CurrencyInput
                        id="input-example"
                        name="input-name"
                        className="form-control"
                        placeholder="$0.00"
                        prefix="$"
                        allowDecimals={true}
                        decimalsLimit={2}
                      />
                    </Col>
                    <Col md={2}>
                      <input type='button' className="btn btn-primary mt-4" value='-' onClick={this.removeClick.bind(this)}/>
                    </Col>
                  </Row>
                <input type='button' className="btn btn-primary mt-3" value='add more' onClick={this.addClick.bind(this)}/>
              </Form.Group>
              <Form.Group controlId="exampleForm.ControlInput1">
                <Row className="mt-3">
                    <Col md={8}>
                      <Form.Label>Category of Accessories</Form.Label>
                      <CreatableSelect
                              isClearable
                              value={null}
                              onChange={this.handleSelectedChange.bind(this)}
                              onInputChange={this.handleInputChange}
                              options={accessory_options}
                              simpleValue={true}
                            />
                    </Col>

                    <Col md={2}>
                      <Form.Label>Pricing</Form.Label>
                      <CurrencyInput
                        id="input-example"
                        name="input-name"
                        className="form-control"
                        placeholder="$0.00"
                        prefix="$"
                        allowDecimals={true}
                        decimalsLimit={2}
                      />
                    </Col>
                    <Col md={2}>
                      <input type='button' className="btn btn-primary mt-4" value='-' onClick={this.removeClick.bind(this)}/>
                    </Col>
                  </Row>
                <input type='button' className="btn btn-primary mt-3" value='add more' onClick={this.addClick.bind(this)}/>
              </Form.Group>
              <Form.Group controlId="exampleForm.ControlInput1">
              {this.createUI()}
               <input type='button' className="btn btn-primary mt-3" value='add more' onClick={this.addClick.bind(this)}/>
              </Form.Group>
                <Form.Group controlId="exampleForm.ControlInput1">
                  <Form.Label>Experience Since:</Form.Label>
                  <DateTimePicker
                      dropUp={false}
                      time={false}
                      max={new Date()}
                      data={[
                        'orange',
                        'red',
                        'blue',
                        'purple'
                      ]}
                    />
                </Form.Group>
                <Form.Group controlId="exampleForm.ControlInput1">
                  <Form.Label>Upload your certificates</Form.Label>
                  {this.createUpload()}
                </Form.Group>
                <Form.Group controlId="exampleForm.ControlTextarea1">
                  <Form.Label>Bio</Form.Label>
                  <Form.Control as="textarea" rows="3" />
                </Form.Group>
                <Button onClick={this.back}>Back</Button>
                <Button onClick={this.saveAndContinue} className="right">Next Step</Button>
              </Form>
                
       
        )
    }
}

export default PersonalDetails;