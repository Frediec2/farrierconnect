import React, { Component } from 'react';
import { Form, Button, Col, Row } from 'react-bootstrap';
import FullCalendar from '@fullcalendar/react'
import dayGridPlugin from '@fullcalendar/daygrid'
import interactionPlugin from "@fullcalendar/interaction";
import timeGridPlugin from '@fullcalendar/timegrid';


import '@fullcalendar/core/main.css'
import '@fullcalendar/daygrid/main.css'
import '@fullcalendar/timegrid/main.css'


class Schedule extends Component{
  
    calendarComponentRef = React.createRef()
  
    state = {
        calendarWeekends: true,
        calendarEvents: [ // initial event data
          
        ]
      }
    
    saveAndContinue = (e) => {
        e.preventDefault();
        this.props.nextStep();
    }

    back  = (e) => {
        e.preventDefault();
        this.props.prevStep();
    }
    
    handleEventDrag = (arg) => {
      console.log(arg)
    }
    
    handleEventResizeStop = (arg) => {
      if (confirm('Would you like to set this available time to every week?')) {
        console.log(arg)
        console.log(arg.event.start)
        var dt = String(arg.event.start.getDay());
        var startTime = arg.event.start.toTimeString();
        var endTime = arg.event.end.toTimeString()
        var datelog = arg.event.start;
        this.setState(state => {
          const calendarEvents = state.calendarEvents.map((item) => {
            if (+item.datelog === +datelog) {
              item = {
                title: 'Available',
                allDay: false,
                daysOfWeek: [ dt ],
                startTime: startTime,
                endTime: endTime,
                backgroundColor: 'green',
                datelog: datelog
              }
              return item;
            } 
          });

          return {
            calendarEvents,
          };
        });
        console.log(this.state)
      } else
      {
        console.log(arg)
        console.log(arg.event.start)
        var dt = String(arg.event.start.getDay());
        var startTime = arg.event.start.toTimeString();
        var endTime = arg.event.end.toTimeString()
        var datelog = arg.event.start;
        this.setState(state => {
          const calendarEvents = state.calendarEvents.map((item) => {
            if (+item.datelog === +datelog) {
              item = {
                title: 'Available',
                allDay: false,
                daysOfWeek: [ dt ],
                startTime: startTime,
                endTime: endTime,
                backgroundColor: 'green',
                datelog: datelog
              }
              return item;
            } 
          });

          return {
            calendarEvents,
          };
        });
        console.log(this.state)
      }
    }
    handleDateClick = (arg) => {
      
      if(arg.view.type == "dayGridMonth") {
        if (confirm('Would you like to set this date to unavailable ' + arg.dateStr + ' ?')) {
          if (confirm('Do you want to repeat this for every week?')) {
            var dt = String(arg.date.getDay());
            this.setState({  // add new event data
              calendarEvents: this.state.calendarEvents.concat({ // creates a new array
                title: 'Not Available',
                daysOfWeek: [ dt ],
                allDay: true,
                backgroundColor: 'red',
                textColor: 'white'
              })
            })
          } else {
            this.setState({  // add new event data
              calendarEvents: this.state.calendarEvents.concat({ // creates a new array
                title: 'Not Available',
                start: arg.date,
                allDay: true,
                backgroundColor: 'red',
                textColor: 'white'
              })
            })
          }
        }
      } else {
        if (confirm('Would you like to set this time to available ?')) {
          if (confirm('Do you want to repeat this for every week?')) {
            var dt = String(arg.date.getDay());
            var startHour = String(arg.date.getHours());
            var startMinute = String(arg.date.getMinutes());
            var startTime = arg.date.toTimeString();
            this.setState({  // add new event data
              calendarEvents: this.state.calendarEvents.concat({ // creates a new array
                title: 'Available',
                daysOfWeek: [ dt ],
                allDay: false,
                startTime: startTime,
                backgroundColor: 'green',
                datelog: arg.date
              })
            })
          } else {
            this.setState({  // add new event data
              calendarEvents: this.state.calendarEvents.concat({ // creates a new array
                title: 'Available',
                start: arg.date,
                allDay: false,
                groupId: 1,
                backgroundColor: 'green'
              })
            })
          }
        }
      }
        
        
      }

    render(){
        const {values: { firstName, lastName, email, age, city, country }} = this.props;

        return(
            <div>
                <h1 className="ui centered">Schedule</h1>
                <FullCalendar
                            defaultView="dayGridMonth"
                            header={{
                              left: 'prev,next today',
                              center: 'title',
                              right: 'dayGridMonth, timeGridWeek'
                            }}
                            displayEventTime={false}
                            editable={true}
                            plugins={[ dayGridPlugin, interactionPlugin, timeGridPlugin ]}
                            ref={ this.calendarComponentRef }
                            weekends={ this.state.calendarWeekends }
                            events={ this.state.calendarEvents }
                            dateClick={ this.handleDateClick }
                            eventResizeStart= { this.handleEventDrag }
                            eventResize= { this.handleEventResizeStop }
                            />
                <Button onClick={this.back}>Back</Button>
                <Button onClick={this.saveAndContinue}>Confirm</Button>
            </div>
        )
    }
}

export default Schedule;